import java.net.*;
import java.io.*;
import java.util.Scanner;
public class Random_Sum_Server_21MIS1118_Vishnu {
    public static void main(String[] args) {
        try{
        ServerSocket ss= new ServerSocket(1234);
        Socket s =ss.accept();
        DataOutputStream dout = new DataOutputStream(s.getOutputStream());
        Scanner sc = new Scanner(System.in);
        
        System.out.println("type 0 to exit");
        System.out.println("enter number 1");
        int a=sc.nextInt();
        System.out.println("enter second number");
        int b=sc.nextInt();
        int sum = a+b;
        dout.writeInt(sum);
        dout.flush();
        ss.close();
        sc.close();
    }
    catch(Exception e){
        System.out.println(e);
    }
}
    
}
