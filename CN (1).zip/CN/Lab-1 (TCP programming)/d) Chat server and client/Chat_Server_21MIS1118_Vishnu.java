import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Chat_Server_21MIS1118_Vishnu {
    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        ServerSocket serverSocket = new ServerSocket(6666);
        Socket socket = serverSocket.accept();
        DataInputStream inputStream = new DataInputStream(socket.getInputStream());
        DataOutputStream outputStream = new DataOutputStream(socket.getOutputStream());
        
        while (true) {
            String message = inputStream.readUTF();
            System.out.println("Client message: " + message);
            
            if (message.equals("stop")) {
                break;
            }
            
            System.out.print("Enter message: ");
            String response = scanner.nextLine();
            
            outputStream.writeUTF(response);
            outputStream.flush();
        }
        
        scanner.close();
        outputStream.close();
        inputStream.close();
        socket.close();
        serverSocket.close();
    }
}
