import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

public class Chat_Client_21MIS1118_Vishnu {
    public static void main(String[] args) throws IOException {  
        Scanner scanner = new Scanner(System.in);  
        Socket socket = new Socket("localhost", 6666);
        DataInputStream inputStream = new DataInputStream(socket.getInputStream());
        DataOutputStream outputStream = new DataOutputStream(socket.getOutputStream());
        
        while (true) {
            System.out.print("Enter message (or 'stop' to exit): ");
            String message = scanner.nextLine();
            
            if (message.equals("stop")) {
                break;
            }
            
            outputStream.writeUTF(message);
            outputStream.flush();
            
            String response = inputStream.readUTF();
            System.out.println("Server response: " + response);
        }
        
        scanner.close();
        outputStream.close();
        inputStream.close();
        socket.close();
    }  
}
