
import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.*;
public class Date_Server_21MIS1118_Vishnu{
    public static void main(String[] args) {
        try{
        ServerSocket ss =new ServerSocket(1234);
        Socket s = ss.accept();
        DataOutputStream dos = new DataOutputStream(s.getOutputStream());

        Date currentDate = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String formattedDate = dateFormat.format(currentDate);
        dos.writeUTF(formattedDate);
        dos.flush();
        ss.close();
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
}
