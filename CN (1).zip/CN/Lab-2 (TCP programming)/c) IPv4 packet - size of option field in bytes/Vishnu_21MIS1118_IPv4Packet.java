public class Vishnu_21MIS1118_IPv4Packet {
    private String headerLengthBinary;
    private int totalLength;
    public Vishnu_21MIS1118_IPv4Packet(String headerLengthBinary, int totalLength) {
        this.headerLengthBinary = headerLengthBinary;
        this.totalLength = totalLength;
    }
    public int getOptionsLength() {
        int headerLength = Integer.parseInt(headerLengthBinary, 2);
        int headerBytes = headerLength * 4;
        int optionsBytes = totalLength - headerBytes;
        return optionsBytes;
    }
    public static void main(String[] args) {
        Vishnu_21MIS1118_IPv4Packet packet = new Vishnu_21MIS1118_IPv4Packet("1000", 1500);
        int optionsLength = packet.getOptionsLength();
        System.out.println("Options field is " + optionsLength + " bytes long.");
    }
}
