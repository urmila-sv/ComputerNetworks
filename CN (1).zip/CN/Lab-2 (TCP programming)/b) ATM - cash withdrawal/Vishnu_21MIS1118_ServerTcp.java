import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

class Vishnu_21MIS1118_ServerTcp {
    private static final int PORT = 9999;
    private Map<String, Customer> customerDetails;
    private Vishnu_21MIS1118_ServerTcp() {
        customerDetails = new HashMap<>();
        customerDetails.put("1234567890", new Customer("John Doe", "1234567890", "1234", 1000));
        customerDetails.put("0987654321", new Customer("Jane Smith", "0987654321", "4321", 500));
    }
    private void start() {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server started. Listening on port " + PORT);
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Client connected: " + clientSocket.getInetAddress());

                ClientHandler clientHandler = new ClientHandler(clientSocket);
                new Thread(clientHandler).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private class ClientHandler implements Runnable {
        private Socket clientSocket;
        private PrintWriter out;
        private BufferedReader in;

        private ClientHandler(Socket socket) {
            clientSocket = socket;
        }
        @Override
        public void run() {
            try {
                out = new PrintWriter(clientSocket.getOutputStream(), true);
                in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                String cardNumber = in.readLine();
                String pin = in.readLine();
                if (validateLogin(cardNumber, pin)) {
                    out.println("Login successful.");
                    String amount = in.readLine();
                    if (withdrawAmount(cardNumber, Double.parseDouble(amount))) {
                        out.println("Withdrawal successful.");
                    } else {
                        out.println("Insufficient balance.");
                    }
                } else {
                    out.println("Invalid login credentials.");
                }
                clientSocket.close();
                System.out.println("Client disconnected: " + clientSocket.getInetAddress());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        private boolean validateLogin(String cardNumber, String pin) {
            Customer customer = customerDetails.get(cardNumber);
            return customer != null && customer.getPin().equals(pin);
        }
        private boolean withdrawAmount(String cardNumber, double amount) {
            Customer customer = customerDetails.get(cardNumber);
            if (customer != null && customer.getBalance() >= amount) {
                customer.setBalance(customer.getBalance() - amount);
                return true;
            }
            return false;
        }
    }
    private static class Customer {
        private String name;
        private String cardNumber;
        private String pin;
        private double balance;
        private Customer(String name, String cardNumber, String pin, double balance) {
            this.name = name;
            this.cardNumber = cardNumber;
            this.pin = pin;
            this.balance = balance;
        }
        public String getName() {
            return name;
        }
        public String getCardNumber() {
            return cardNumber;
        }
        public String getPin() {
            return pin;
        }
        public double getBalance() {
            return balance;
        }
        public void setBalance(double balance) {
            this.balance = balance;
        }
    }
    public static void main(String[] args) {
        Vishnu_21MIS1118_ServerTcp server = new Vishnu_21MIS1118_ServerTcp();
        server.start();
    }
}