
import java.io.*;
import java.net.Socket;

class Vishnu_21MIS1118_ClientTcp {
    private static final String SERVER_IP = "localhost";
    private static final int SERVER_PORT = 9999;

    public static void main(String[] args) {
        try (Socket socket = new Socket(SERVER_IP, SERVER_PORT)) {
            BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in));
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            System.out.print("Enter card number: ");
            String cardNumber = userInput.readLine();
            out.println(cardNumber);

            System.out.print("Enter PIN: ");
            String pin = userInput.readLine();
            out.println(pin);

            String serverResponse = in.readLine();
            System.out.println("Server response: " + serverResponse);

            if (serverResponse.equals("Login successful.")) {
                System.out.print("Enter withdrawal amount: ");
                String amount = userInput.readLine();
                out.println(amount);

                serverResponse = in.readLine();
                System.out.println("Server response: " + serverResponse);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}