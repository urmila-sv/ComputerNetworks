import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
public class Vishnu_21MIS1118_Client {
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost", 12345);
            BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Enter the message: ");
            String message = userInput.readLine();
            System.out.print("Enter the n-value: ");
            int nValue = Integer.parseInt(userInput.readLine());
            output.println(message);
            output.println(nValue);
            String encodedMessage = input.readLine();
            System.out.println("Encoded message: " + encodedMessage);
            input.close();
            output.close();
            socket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}