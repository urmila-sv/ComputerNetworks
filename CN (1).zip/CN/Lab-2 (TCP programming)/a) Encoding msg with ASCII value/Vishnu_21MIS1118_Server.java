import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
public class Vishnu_21MIS1118_Server {
    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(12345);
            System.out.println("Server listening on port 12345...");
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Client connected: " + clientSocket.getInetAddress());
                BufferedReader input = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                PrintWriter output = new PrintWriter(clientSocket.getOutputStream(), true);
                String message = input.readLine();
                int nValue = Integer.parseInt(input.readLine());
                String encodedMessage = encodeMessage(message, nValue);
                output.println(encodedMessage);
                input.close();
                output.close();
                clientSocket.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private static boolean isPrime(int num) {
        if (num < 2) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }
    private static String encodeMessage(String message, int nValue) {
        StringBuilder encodedMessage = new StringBuilder();
        int primeCount = 0;
        for (char c : message.toCharArray()) {
            if (isPrime(nValue)) {
                primeCount++;
                int remainder = c % nValue;
                encodedMessage.append(remainder).append(" ");
            } else {
                encodedMessage.append(c);
            }
        }
        if (primeCount == 0) {
            return "Invalid n-value: It should be a prime number.";
        } else {
            return encodedMessage.toString().trim();
        }
    }
}