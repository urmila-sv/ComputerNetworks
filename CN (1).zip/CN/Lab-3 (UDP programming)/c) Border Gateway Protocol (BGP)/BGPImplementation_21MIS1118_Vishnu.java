import java.util.HashMap;
import java.util.Map;

// Represents a BGP router
class Router {
    private String routerId;
    private Map<String, String> routingTable;

    public Router(String routerId) {
        this.routerId = routerId;
        this.routingTable = new HashMap<>();
    }

    public String getId() {
        return routerId;
    }

    public void advertiseRoute(String networkPrefix, String nextHop) {
        routingTable.put(networkPrefix, nextHop);
    }

    public String getNextHop(String networkPrefix) {
        return routingTable.get(networkPrefix);
    }
}

// Represents the BGP protocol handler
class BGPProtocol {
    private Map<String, Router> routers;

    public BGPProtocol() {
        this.routers = new HashMap<>();
    }

    public void addRouter(Router router) {
        routers.put(router.getId(), router);
    }

    public void exchangeRoutes() {
        for (Router router : routers.values()) {
            // Simulate BGP route exchange process
            // Implement BGP message exchange and route update logic here
        }
    }
}

public class BGPImplementation_21MIS1118_Vishnu {
    public static void main(String[] args) {
        Router router1 = new Router("R1");
        Router router2 = new Router("R2");

        BGPProtocol bgp = new BGPProtocol();
        bgp.addRouter(router1);
        bgp.addRouter(router2);

        // Configure routing information
        router1.advertiseRoute("192.168.0.0/24", "192.168.1.1");
        router2.advertiseRoute("10.0.0.0/8", "10.1.1.1");

        // Exchange routes between routers
        bgp.exchangeRoutes();

        // Get next hop for a network prefix
        String nextHop = router1.getNextHop("10.0.0.0/8");
        System.out.println("Next hop for 10.0.0.0/8: " + nextHop);
    }
}
