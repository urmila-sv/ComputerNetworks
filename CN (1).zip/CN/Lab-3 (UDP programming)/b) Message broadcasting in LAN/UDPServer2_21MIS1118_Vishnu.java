import java.net.*;

public class UDPServer2_21MIS1118_Vishnu {
   public static void main(String args[]) throws Exception {
      DatagramSocket serverSocket = new DatagramSocket();
      InetAddress broadcastIP = InetAddress.getByName("255.255.255.255");
      byte[] sendData = new byte[1024];
      String sentence = "Hello, world!";
      sendData = sentence.getBytes();
      DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, broadcastIP, 9876);
      serverSocket.send(sendPacket);
      System.out.println("Message sent to LAN broadcast address");
      serverSocket.close();
   }
}
