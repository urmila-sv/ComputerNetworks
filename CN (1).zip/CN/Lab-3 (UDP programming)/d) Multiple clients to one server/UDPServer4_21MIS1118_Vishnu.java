import java.net.*;
import java.util.*;

public class UDPServer4_21MIS1118_Vishnu {
    public static void main(String args[]) throws Exception {
        DatagramSocket serverSocket = new DatagramSocket(9876);
        byte[] receiveData = new byte[1024];
        List<InetAddress> clients = new ArrayList<>();
        List<Integer> ids = new ArrayList<>();
        int id = 0;

        System.out.println("Server started on port 9876");

        while (true) {
            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
            serverSocket.receive(receivePacket);
            InetAddress clientAddress = receivePacket.getAddress();

            if (!clients.contains(clientAddress)) {
                clients.add(clientAddress);
                ids.add(id);
                id++;
                System.out.println("New client connected: " + clientAddress);
            }

            int clientId = ids.get(clients.indexOf(clientAddress));
            String message = "Your unique identifier is " + clientId;
            byte[] sendData = message.getBytes();
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, clientAddress, receivePacket.getPort());
            serverSocket.send(sendPacket);

            System.out.println("Received request from client " + clientId + ": " + new String(receivePacket.getData()));

            Thread requestHandler = new Thread(new RequestHandler(receivePacket, clientId));
            requestHandler.start();
        }
    }
}

class RequestHandler implements Runnable {
    private DatagramPacket packet;
    private int clientId;

    public RequestHandler(DatagramPacket packet, int clientId) {
        this.packet = packet;
        this.clientId = clientId;
    }

    public void run() {
        try {
            String requestData = new String(packet.getData()).trim();
            System.out.println("Processing request from client " + clientId + ": " + requestData);

            // Process request here

            String responseData = "Response from server";
            byte[] sendData = responseData.getBytes();
            DatagramSocket socket = new DatagramSocket();
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, packet.getAddress(), packet.getPort());
            socket.send(sendPacket);
            socket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
