import java.net.*;
import java.util.*;

public class UDPClient4_21MIS1118_Vishnu {
    public static void main(String args[]) throws Exception {
        InetAddress serverAddress = InetAddress.getByName("localhost");
        DatagramSocket clientSocket = new DatagramSocket();

        byte[] sendData = new byte[1024];
        byte[] receiveData = new byte[1024];

        // Send request from client 1
        String message1 = "Hello from client 1";
        sendData = message1.getBytes();
        DatagramPacket sendPacket1 = new DatagramPacket(sendData, sendData.length, serverAddress, 9876);
        clientSocket.send(sendPacket1);

        DatagramPacket receivePacket1 = new DatagramPacket(receiveData, receiveData.length);
        clientSocket.receive(receivePacket1);
        String response1 = new String(receivePacket1.getData()).trim();
        System.out.println("Response from server to client 1: " + response1);

        // Send request from client 2
        String message2 = "Hello from client 2";
        sendData = message2.getBytes();
        DatagramPacket sendPacket2 = new DatagramPacket(sendData, sendData.length, serverAddress, 9876);
        clientSocket.send(sendPacket2);

        DatagramPacket receivePacket2 = new DatagramPacket(receiveData, receiveData.length);
        clientSocket.receive(receivePacket2);
        String response2 = new String(receivePacket2.getData()).trim();
        System.out.println("Response from server to client 2: " + response2);

        // Send request from client 3
        String message3 = "Hello from client 3";
        sendData = message3.getBytes();
        DatagramPacket sendPacket3 = new DatagramPacket(sendData, sendData.length, serverAddress, 9876);
        clientSocket.send(sendPacket3);

        DatagramPacket receivePacket3 = new DatagramPacket(receiveData, receiveData.length);
        clientSocket.receive(receivePacket3);
        String response3 = new String(receivePacket3.getData()).trim();
        System.out.println("Response from server to client 3: " + response3);

        clientSocket.close();
    }
}
